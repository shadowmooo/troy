create definer = rangeradmin@`%` view vx_trx_log as
select `ranger`.`x_trx_log`.`id`                       AS `id`,
       `ranger`.`x_trx_log`.`create_time`              AS `create_time`,
       `ranger`.`x_trx_log`.`update_time`              AS `update_time`,
       `ranger`.`x_trx_log`.`added_by_id`              AS `added_by_id`,
       `ranger`.`x_trx_log`.`upd_by_id`                AS `upd_by_id`,
       `ranger`.`x_trx_log`.`class_type`               AS `class_type`,
       `ranger`.`x_trx_log`.`object_id`                AS `object_id`,
       `ranger`.`x_trx_log`.`parent_object_id`         AS `parent_object_id`,
       `ranger`.`x_trx_log`.`parent_object_class_type` AS `parent_object_class_type`,
       `ranger`.`x_trx_log`.`attr_name`                AS `attr_name`,
       `ranger`.`x_trx_log`.`parent_object_name`       AS `parent_object_name`,
       `ranger`.`x_trx_log`.`object_name`              AS `object_name`,
       `ranger`.`x_trx_log`.`prev_val`                 AS `prev_val`,
       `ranger`.`x_trx_log`.`new_val`                  AS `new_val`,
       `ranger`.`x_trx_log`.`trx_id`                   AS `trx_id`,
       `ranger`.`x_trx_log`.`action`                   AS `action`,
       `ranger`.`x_trx_log`.`sess_id`                  AS `sess_id`,
       `ranger`.`x_trx_log`.`req_id`                   AS `req_id`,
       `ranger`.`x_trx_log`.`sess_type`                AS `sess_type`
from `ranger`.`x_trx_log`
where `ranger`.`x_trx_log`.`id` in
      (select min(`ranger`.`x_trx_log`.`id`) from `ranger`.`x_trx_log` group by `ranger`.`x_trx_log`.`trx_id`);

