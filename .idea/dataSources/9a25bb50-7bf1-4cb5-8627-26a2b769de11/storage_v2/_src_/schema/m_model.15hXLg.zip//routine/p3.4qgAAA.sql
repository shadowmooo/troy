create
    definer = root@`%` procedure p3()
BEGIN
	SELECT
		*
	FROM
		global_config;
	END;

