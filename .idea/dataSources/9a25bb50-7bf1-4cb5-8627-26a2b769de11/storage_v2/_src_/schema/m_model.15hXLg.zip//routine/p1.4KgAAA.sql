create
    definer = root@`%` procedure p1()
BEGIN
SELECT * from global_config;

END;

