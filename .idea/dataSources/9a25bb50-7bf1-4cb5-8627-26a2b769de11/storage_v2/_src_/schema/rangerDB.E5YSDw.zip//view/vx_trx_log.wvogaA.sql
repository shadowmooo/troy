create definer = ranger@`%` view vx_trx_log as
select `rangerDB`.`x_trx_log`.`id`                       AS `id`,
       `rangerDB`.`x_trx_log`.`create_time`              AS `create_time`,
       `rangerDB`.`x_trx_log`.`update_time`              AS `update_time`,
       `rangerDB`.`x_trx_log`.`added_by_id`              AS `added_by_id`,
       `rangerDB`.`x_trx_log`.`upd_by_id`                AS `upd_by_id`,
       `rangerDB`.`x_trx_log`.`class_type`               AS `class_type`,
       `rangerDB`.`x_trx_log`.`object_id`                AS `object_id`,
       `rangerDB`.`x_trx_log`.`parent_object_id`         AS `parent_object_id`,
       `rangerDB`.`x_trx_log`.`parent_object_class_type` AS `parent_object_class_type`,
       `rangerDB`.`x_trx_log`.`attr_name`                AS `attr_name`,
       `rangerDB`.`x_trx_log`.`parent_object_name`       AS `parent_object_name`,
       `rangerDB`.`x_trx_log`.`object_name`              AS `object_name`,
       `rangerDB`.`x_trx_log`.`prev_val`                 AS `prev_val`,
       `rangerDB`.`x_trx_log`.`new_val`                  AS `new_val`,
       `rangerDB`.`x_trx_log`.`trx_id`                   AS `trx_id`,
       `rangerDB`.`x_trx_log`.`action`                   AS `action`,
       `rangerDB`.`x_trx_log`.`sess_id`                  AS `sess_id`,
       `rangerDB`.`x_trx_log`.`req_id`                   AS `req_id`,
       `rangerDB`.`x_trx_log`.`sess_type`                AS `sess_type`
from `rangerDB`.`x_trx_log`
where `rangerDB`.`x_trx_log`.`id` in
      (select min(`rangerDB`.`x_trx_log`.`id`) from `rangerDB`.`x_trx_log` group by `rangerDB`.`x_trx_log`.`trx_id`);

